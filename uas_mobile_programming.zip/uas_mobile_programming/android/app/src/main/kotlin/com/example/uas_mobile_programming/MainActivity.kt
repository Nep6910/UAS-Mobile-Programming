package com.example.uas_mobile_programming

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
