import 'package:flutter/material.dart';
import 'package:uas_mobile_programming/denim/denim1.dart';
import 'package:uas_mobile_programming/denim/denim2.dart';
import 'package:uas_mobile_programming/denim/denim3.dart';
import 'package:uas_mobile_programming/fabric/fabric1.dart';
import 'package:uas_mobile_programming/fabric/fabric2.dart';
import 'package:uas_mobile_programming/fabric/fabric3.dart';
import 'package:uas_mobile_programming/leather/leather1.dart';
import 'package:uas_mobile_programming/leather/leather2.dart';
import 'package:uas_mobile_programming/leather/leather3.dart';
import 'package:uas_mobile_programming/polyester/polyester1.dart';
import 'package:uas_mobile_programming/polyester/polyester2.dart';
import 'package:uas_mobile_programming/polyester/polyester3.dart';

class Page1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DefaultTabController(
        length: 4,
        child: Scaffold(
          /*AppBar*/
          appBar: AppBar(
              toolbarHeight: 100,
              backgroundColor: Colors.white,
              leading: Icon(Icons.menu, color: Colors.black, size: 30),
              title: Text('Discover',
                  style: TextStyle(color: Colors.black, fontSize: 24)),
              actions: <Widget>[
                Container(
                    padding: EdgeInsets.only(right: 15),
                    child: IconButton(
                        icon: Icon(Icons.search, color: Colors.black, size: 30),
                        onPressed: () {
                          showSearch(context: context, delegate: DataSearch());
                        }))
              ],
              bottom: PreferredSize(
                  preferredSize: Size(0, 0),
                  child: Container(
                    height: 40,
                    child: TabBar(
                      tabs: [
                        Text('Leather',
                            style:
                                TextStyle(fontSize: 16, color: Colors.black)),
                        Text('Fabric',
                            style:
                                TextStyle(fontSize: 16, color: Colors.black)),
                        Text('Polyester',
                            style:
                                TextStyle(fontSize: 16, color: Colors.black)),
                        Text('Denim',
                            style:
                                TextStyle(fontSize: 16, color: Colors.black)),
                      ],
                    ),
                  ))),
          drawer: Drawer(),

          /*Body(TabBarView)*/
          body: TabBarView(
            children: [
              /*Leather*/
              ListView(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => leather1()),
                            );
                          },
                          child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.red[400],
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(20))),
                              margin: EdgeInsets.only(top: 15),
                              height: 300,
                              width: 200,
                              child: Column(children: <Widget>[
                                Container(
                                    margin: EdgeInsets.only(top: 10, right: 15),
                                    alignment: Alignment.centerRight,
                                    child: Icon(Icons.favorite_border,
                                        color: Colors.white)),
                                Container(
                                    margin: EdgeInsets.only(top: 10, left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('B.A.G',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    margin: EdgeInsets.only(left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('RED LEATHER',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    margin: EdgeInsets.only(left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('Rp250,000',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    child: Image.asset(
                                  'images/leather1.png',
                                  height: 200,
                                )),
                              ]))),
                      Container(
                          margin:
                              EdgeInsets.only(top: 30, left: 35, bottom: 20),
                          alignment: Alignment.centerLeft,
                          child: Text('More', style: TextStyle(fontSize: 20))),
                      Container(
                          margin: EdgeInsets.only(bottom: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              InkWell(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => leather2()),
                                    );
                                  },
                                  child: Stack(
                                    children: <Widget>[
                                      Container(
                                          width: 150,
                                          height: 150,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.5),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: Offset(0, 3),
                                                ),
                                              ]),
                                          child: Column(
                                            children: [
                                              Container(
                                                  margin: EdgeInsets.only(
                                                      top: 10, right: 10),
                                                  alignment:
                                                      Alignment.centerRight,
                                                  child: Icon(
                                                      Icons.favorite_border,
                                                      color: Colors.black)),
                                              Container(
                                                  child: Image.asset(
                                                      'images/leather2.png')),
                                            ],
                                          )),
                                      Positioned(
                                        child: Container(
                                            color: Colors.brown,
                                            height: 50,
                                            width: 20),
                                      )
                                    ],
                                  )),
                              InkWell(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => leather3()),
                                    );
                                  },
                                  child: Stack(
                                    children: <Widget>[
                                      Container(
                                          width: 150,
                                          height: 150,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.5),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: Offset(0, 3),
                                                ),
                                              ]),
                                          child: Column(
                                            children: [
                                              Container(
                                                  margin: EdgeInsets.only(
                                                      top: 10, right: 10),
                                                  alignment:
                                                      Alignment.centerRight,
                                                  child: Icon(
                                                      Icons.favorite_border,
                                                      color: Colors.black)),
                                              Container(
                                                  child: Image.asset(
                                                      'images/leather3.png',
                                                      height: 110)),
                                            ],
                                          )),
                                      Positioned(
                                        child: Container(
                                            color: Colors.brown,
                                            height: 50,
                                            width: 20),
                                      )
                                    ],
                                  )),
                            ],
                          ))
                    ],
                  ),
                ],
              ),

              /*Fabric*/
              ListView(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => fabric1()),
                            );
                          },
                          child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.grey[700],
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(20))),
                              margin: EdgeInsets.only(top: 15),
                              height: 300,
                              width: 200,
                              child: Column(children: <Widget>[
                                Container(
                                    margin: EdgeInsets.only(top: 10, right: 15),
                                    alignment: Alignment.centerRight,
                                    child: Icon(Icons.favorite_border,
                                        color: Colors.white)),
                                Container(
                                    margin: EdgeInsets.only(top: 10, left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('B.A.G',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    margin: EdgeInsets.only(left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('WHITE FABRIC',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    margin: EdgeInsets.only(left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('Rp300,000',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    child: Image.asset(
                                  'images/fabric1.png',
                                  height: 200,
                                )),
                              ]))),
                      Container(
                          margin:
                              EdgeInsets.only(top: 30, left: 35, bottom: 20),
                          alignment: Alignment.centerLeft,
                          child: Text('More', style: TextStyle(fontSize: 20))),
                      Container(
                          margin: EdgeInsets.only(bottom: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              InkWell(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => fabric2()),
                                    );
                                  },
                                  child: Stack(
                                    children: <Widget>[
                                      Container(
                                          width: 150,
                                          height: 150,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.5),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: Offset(0, 3),
                                                ),
                                              ]),
                                          child: Column(
                                            children: [
                                              Container(
                                                  margin: EdgeInsets.only(
                                                      top: 10, right: 10),
                                                  alignment:
                                                      Alignment.centerRight,
                                                  child: Icon(
                                                      Icons.favorite_border,
                                                      color: Colors.black)),
                                              Container(
                                                  child: Image.asset(
                                                      'images/fabric2.png',
                                                      height: 110)),
                                            ],
                                          )),
                                      Positioned(
                                        child: Container(
                                            color: Colors.yellow[800],
                                            height: 50,
                                            width: 20),
                                      )
                                    ],
                                  )),
                              InkWell(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => fabric3()),
                                    );
                                  },
                                  child: Stack(
                                    children: <Widget>[
                                      Container(
                                          width: 150,
                                          height: 150,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.5),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: Offset(0, 3),
                                                ),
                                              ]),
                                          child: Column(
                                            children: [
                                              Container(
                                                  margin: EdgeInsets.only(
                                                      top: 10, right: 10),
                                                  alignment:
                                                      Alignment.centerRight,
                                                  child: Icon(
                                                      Icons.favorite_border,
                                                      color: Colors.black)),
                                              Container(
                                                  child: Image.asset(
                                                      'images/fabric3.png',
                                                      height: 110)),
                                            ],
                                          )),
                                      Positioned(
                                        child: Container(
                                            color: Colors.black,
                                            height: 50,
                                            width: 20),
                                      )
                                    ],
                                  )),
                            ],
                          ))
                    ],
                  ),
                ],
              ),

              /*Polyester*/
              ListView(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => polyester1()),
                            );
                          },
                          child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.grey[700],
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(20))),
                              margin: EdgeInsets.only(top: 15),
                              height: 300,
                              width: 200,
                              child: Column(children: <Widget>[
                                Container(
                                    margin: EdgeInsets.only(top: 10, right: 15),
                                    alignment: Alignment.centerRight,
                                    child: Icon(Icons.favorite_border,
                                        color: Colors.white)),
                                Container(
                                    margin: EdgeInsets.only(top: 10, left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('B.A.G',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    margin: EdgeInsets.only(left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('GREY POLYESTER',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    margin: EdgeInsets.only(left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('Rp200,000',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    child: Image.asset(
                                  'images/polyester1.png',
                                  height: 200,
                                  width: 170,
                                )),
                              ]))),
                      Container(
                          margin:
                              EdgeInsets.only(top: 30, left: 35, bottom: 20),
                          alignment: Alignment.centerLeft,
                          child: Text('More', style: TextStyle(fontSize: 20))),
                      Container(
                          margin: EdgeInsets.only(bottom: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              InkWell(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => polyester2()),
                                    );
                                  },
                                  child: Stack(
                                    children: <Widget>[
                                      Container(
                                          width: 150,
                                          height: 150,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.5),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: Offset(0, 3),
                                                ),
                                              ]),
                                          child: Column(
                                            children: [
                                              Container(
                                                  margin: EdgeInsets.only(
                                                      top: 10, right: 10),
                                                  alignment:
                                                      Alignment.centerRight,
                                                  child: Icon(
                                                      Icons.favorite_border,
                                                      color: Colors.black)),
                                              Container(
                                                  child: Image.asset(
                                                      'images/polyester2.png',
                                                      height: 115)),
                                            ],
                                          )),
                                      Positioned(
                                        child: Container(
                                            color: Colors.black,
                                            height: 50,
                                            width: 20),
                                      )
                                    ],
                                  )),
                              InkWell(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => polyester3()),
                                    );
                                  },
                                  child: Stack(
                                    children: <Widget>[
                                      Container(
                                          width: 150,
                                          height: 150,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.5),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: Offset(0, 3),
                                                ),
                                              ]),
                                          child: Column(
                                            children: [
                                              Container(
                                                  margin: EdgeInsets.only(
                                                      top: 10, right: 10),
                                                  alignment:
                                                      Alignment.centerRight,
                                                  child: Icon(
                                                      Icons.favorite_border,
                                                      color: Colors.black)),
                                              Container(
                                                  child: Image.asset(
                                                      'images/polyester3.png',
                                                      height: 105)),
                                            ],
                                          )),
                                      Positioned(
                                        child: Container(
                                            color: Colors.brown,
                                            height: 50,
                                            width: 20),
                                      )
                                    ],
                                  )),
                            ],
                          ))
                    ],
                  ),
                ],
              ),

              /*Denim*/
              ListView(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => denim1()),
                            );
                          },
                          child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.blue[900],
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(20))),
                              margin: EdgeInsets.only(top: 15),
                              height: 300,
                              width: 200,
                              child: Column(children: <Widget>[
                                Container(
                                    margin: EdgeInsets.only(top: 10, right: 15),
                                    alignment: Alignment.centerRight,
                                    child: Icon(Icons.favorite_border,
                                        color: Colors.white)),
                                Container(
                                    margin: EdgeInsets.only(top: 10, left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('B.A.G',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    margin: EdgeInsets.only(left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('BLUE DENIM',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    margin: EdgeInsets.only(left: 15),
                                    alignment: Alignment.centerLeft,
                                    child: Text('Rp350,000',
                                        style: TextStyle(color: Colors.white))),
                                Container(
                                    child: Image.asset(
                                  'images/denim1.png',
                                  height: 200,
                                )),
                              ]))),
                      Container(
                          margin:
                              EdgeInsets.only(top: 30, left: 35, bottom: 20),
                          alignment: Alignment.centerLeft,
                          child: Text('More', style: TextStyle(fontSize: 20))),
                      Container(
                          margin: EdgeInsets.only(bottom: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              InkWell(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => denim2()),
                                    );
                                  },
                                  child: Stack(
                                    children: <Widget>[
                                      Container(
                                          width: 150,
                                          height: 150,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.5),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: Offset(0, 3),
                                                ),
                                              ]),
                                          child: Column(
                                            children: [
                                              Container(
                                                  margin: EdgeInsets.only(
                                                      top: 10, right: 10),
                                                  alignment:
                                                      Alignment.centerRight,
                                                  child: Icon(
                                                      Icons.favorite_border,
                                                      color: Colors.black)),
                                              Container(
                                                  child: Image.asset(
                                                      'images/denim2.png',
                                                      height: 110)),
                                            ],
                                          )),
                                      Positioned(
                                        child: Container(
                                            color: Colors.blue[900],
                                            height: 50,
                                            width: 20),
                                      )
                                    ],
                                  )),
                              InkWell(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => denim3()),
                                    );
                                  },
                                  child: Stack(
                                    children: <Widget>[
                                      Container(
                                          width: 150,
                                          height: 150,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey
                                                      .withOpacity(0.5),
                                                  spreadRadius: 5,
                                                  blurRadius: 7,
                                                  offset: Offset(0, 3),
                                                ),
                                              ]),
                                          child: Column(
                                            children: [
                                              Container(
                                                  margin: EdgeInsets.only(
                                                      top: 10, right: 10),
                                                  alignment:
                                                      Alignment.centerRight,
                                                  child: Icon(
                                                      Icons.favorite_border,
                                                      color: Colors.black)),
                                              Container(
                                                  child: Image.asset(
                                                      'images/denim3.png',
                                                      height: 110)),
                                            ],
                                          )),
                                      Positioned(
                                        child: Container(
                                            color: Colors.blueGrey,
                                            height: 50,
                                            width: 20),
                                      )
                                    ],
                                  )),
                            ],
                          ))
                    ],
                  ),
                ],
              ),
            ],
          ),

          /*BottomNavigationBar*/
          bottomNavigationBar:
              BottomNavigationBar(type: BottomNavigationBarType.fixed, items: <
                  BottomNavigationBarItem>[
            BottomNavigationBarItem(
                icon: Icon(Icons.shopping_cart, color: Colors.black, size: 30),
                title: Text('Shop',
                    style: TextStyle(color: Colors.black, fontSize: 16))),
            BottomNavigationBarItem(
                icon: Icon(Icons.home, color: Colors.black, size: 30),
                title: Text('Home',
                    style: TextStyle(color: Colors.black, fontSize: 16))),
            BottomNavigationBarItem(
                icon: Icon(Icons.account_circle, color: Colors.black, size: 30),
                title: Text('Account',
                    style: TextStyle(color: Colors.black, fontSize: 16))),
          ]),
        ),
      ),
    );
  }
}

class DataSearch extends SearchDelegate<String> {
  final produk = [
    "Leather 1",
    "Leather 2",
    "Leather 3",
    "Fabric 1",
    "Fabric 2",
    "Fabric 3",
    "Polyester 1",
    "Polyester 2",
    "Polyester 3",
    "Denim 1",
    "Denim 2",
    "Denim 3",
  ];

  final recentProduk = ["Leather 1", "Fabric 1", "Polyester 1", "Denim 1"];

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
          icon: Icon(Icons.clear),
          onPressed: () {
            query = "";
          })
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
        icon: AnimatedIcon(
          icon: AnimatedIcons.menu_arrow,
          progress: transitionAnimation,
        ),
        onPressed: () {
          close(context, null);
        });
  }

  @override
  Widget buildResults(BuildContext context) {}

  @override
  Widget buildSuggestions(BuildContext context) {
    final suggestionList = query.isEmpty
        ? recentProduk
        : produk.where((p) => p.startsWith(query)).toList();

    return ListView.builder(
      itemBuilder: (context, index) => ListTile(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => leather1()),
          );
        },
        leading: Icon(Icons.business_center),
        title: RichText(
            text: TextSpan(
                text: suggestionList[index].substring(0, query.length),
                style:
                    TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                children: [
              TextSpan(
                  text: suggestionList[index].substring(query.length),
                  style: TextStyle(color: Colors.grey))
            ])),
      ),
      itemCount: suggestionList.length,
    );
  }
}
