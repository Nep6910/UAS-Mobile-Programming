import 'package:flutter/material.dart';

class denim3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            elevation: 0,
            toolbarHeight: 65,
            backgroundColor: Colors.blue[300],
            actionsIconTheme:
                IconThemeData(size: 30.0, color: Colors.white, opacity: 10.0),
            leading: GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(
                Icons.arrow_back_outlined,
                size: 35,
              ),
            ),
            actions: <Widget>[
              Padding(
                padding: EdgeInsets.only(right: 20),
                child: GestureDetector(
                  onTap: () {},
                  child: Icon(
                    Icons.favorite_border,
                    size: 35,
                  ),
                ),
              ),
            ]),
        body: (ListView(children: <Widget>[
          Stack(children: <Widget>[
            Column(
              children: [
                Container(
                    height: MediaQuery.of(context).size.height * 0.35,
                    width: MediaQuery.of(context).size.width * 1,
                    decoration: BoxDecoration(
                        color: Colors.blue[300],
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(125))),
                    child: Column(children: <Widget>[
                      Container(
                          padding: EdgeInsets.only(left: 20),
                          child: Row(children: <Widget>[
                            Text(
                              'B.A.G',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold),
                            )
                          ])),
                      Container(
                          padding: EdgeInsets.only(left: 20),
                          child: Row(children: <Widget>[
                            Text('BLUE DENIM',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 20))
                          ])),
                      Container(
                          padding: EdgeInsets.only(left: 20, top: 30),
                          child: Row(children: <Widget>[
                            Text('Rp 310,000',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 20))
                          ])),
                    ])),
                Container(
                  margin: EdgeInsets.only(top: 120),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Container(
                            margin: EdgeInsets.only(left: 20),
                            child: Column(children: <Widget>[
                              Container(
                                  margin: EdgeInsets.only(right: 30, bottom: 5),
                                  child: Text('Colour',
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold))),
                              Row(children: <Widget>[
                                Container(
                                    margin: EdgeInsets.only(right: 10),
                                    child: Icon(Icons.circle,
                                        color: Colors.blue[300])),
                                Container(
                                    margin: EdgeInsets.only(right: 10),
                                    child:
                                        Icon(Icons.circle, color: Colors.grey)),
                                Container(
                                    child: Icon(Icons.circle,
                                        color: Colors.black)),
                              ])
                            ])),
                        Container(
                            margin: EdgeInsets.only(right: 20),
                            child: Column(children: <Widget>[
                              Container(
                                  margin: EdgeInsets.only(right: 55, bottom: 5),
                                  child: Text('Size',
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold))),
                              Container(
                                  child: Text('25 x 10 cm',
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 20))),
                            ]))
                      ]),
                ),
                Row(mainAxisAlignment: MainAxisAlignment.start, children: <
                    Widget>[
                  Container(
                      width: 370,
                      margin: EdgeInsets.only(left: 20, top: 30, bottom: 30),
                      child: Text(
                          'Tas yg terbuat dari material kain cotton atau kapas yang sama dengan bahan pembuatan celana levis. ',
                          style: TextStyle(color: Colors.black, fontSize: 20))),
                ]),
                Container(
                  margin: EdgeInsets.only(bottom: 20),
                  width: MediaQuery.of(context).size.width * 0.9,
                  decoration: BoxDecoration(
                      color: Colors.blue[300],
                      borderRadius: BorderRadius.all(Radius.circular(15))),
                  child: Container(
                      alignment: Alignment.center,
                      padding: EdgeInsets.only(
                          top: 10, bottom: 10, left: 15, right: 15),
                      child: Text('Add to Cart',
                          style: TextStyle(color: Colors.white, fontSize: 20))),
                )
              ],
            ),
            Positioned(
                right: 70,
                top: 30,
                child: Container(
                    child: Image.asset('images/denim3.png', height: 280))),
          ])
        ])));
  }
}
